# Group Chat App
This is a simulated project structure.